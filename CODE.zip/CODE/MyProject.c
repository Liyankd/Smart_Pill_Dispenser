    unsigned char clock[2];
    unsigned char a[4][2]={{0,0},{0,0},{0,0},{0,0}};
    unsigned int dcntr, tick=0;
    unsigned char lim, templim;
    unsigned char pills, temp;
    unsigned int timer=11;
    unsigned char i, E;
    char keys[17]={'/',1,2,3,'A',4,5,6,'B',7,8,9,'C','*',0,'#','D'};
    char keypadPort at PORTD; //keypad
     unsigned char *welcome="Welcome to our Smart Pill Dispenser.";
    unsigned char *welcome2="Send 'r' for refill, 'd' for pill drop.";
    unsigned char *stars="**************************.";
    unsigned char missed=0;
    unsigned char pilltaken=0;
    unsigned char myRxBuffer;
    unsigned char myRxFlag = 0;

// LCD pinout settings
sbit LCD_RS at RB2_bit;
sbit LCD_EN at RB3_bit;
sbit LCD_D7 at RB7_bit;
sbit LCD_D6 at RB6_bit;
sbit LCD_D5 at RB5_bit;
sbit LCD_D4 at RB4_bit;

// Pin direction
sbit LCD_RS_Direction at TRISB2_bit;
sbit LCD_EN_Direction at TRISB3_bit;
sbit LCD_D7_Direction at TRISB7_bit;
sbit LCD_D6_Direction at TRISB6_bit;
sbit LCD_D5_Direction at TRISB5_bit;
sbit LCD_D4_Direction at TRISB4_bit;

void msDelay(unsigned int k){
dcntr=0;
while  (dcntr<k);
}
void Delay_us(unsigned int usCnt){
    unsigned int us=0;
  for(us=0;us<usCnt;us++){
    asm NOP;//0.5 uS
    asm NOP;//0.5uS
  }
}

void display();
unsigned char in2();
unsigned char in1();
void configure();
void USART_Init(void);
void USART_Tx(unsigned char myChar);
void ADC_init(void);
unsigned int read_temp(void);
void drop_pill();
void servoRotate0();
void servoRotate180();
void ask( char *text);

  void interrupt(){
  if (INTCON&0x02 && INTCON&0x10){
  PORTA=0x00;
servoRotate180();
servoRotate0();
pills--;
  timer=11;
  pilltaken=1;

INTCON=INTCON&0xED; //Turn off INTE and INTF
}
   if(INTCON&0x04){
      TMR0=60;
      tick++;
      Dcntr+=25;
      /*For simulation and testing, we're scaling every 1 minute in system as 1 second in real life
      However, if you want to run the system ar normal, just change the condition in the next if statement
      to (tick==2400)
      */
      if(tick==40){
      tick=0;
      clock[1]++;
      timer++;

      //Reset Hour/Day
      if(clock[1]==60) {
      clock[0]++;
      clock[1]=0;}
      if(clock[0]==24) {
      clock[1]=0;
      clock[0]=0;}

      if(E){
      //Check if Clock==Any of the set alarms after system configuration
      for (i=0;i<lim;i++){
      if (clock[0]==a[i][0]&& clock[1]==a[i][1]){
      timer=0;
      PORTA= 0xFF;
      INTCON=INTCON|0x10; //Enable External interrupt on PORTB0 (Hand Detection by IR Sensor)
      break;
      } }
      if(timer<10)
      PORTA= ~PORTA;

      if(timer==10){  //10 minutes have passed and no hand detection. Missed Dose
      PORTA= PORTA& 0x00;
      INTCON=INTCON&0xEF; //Disable External Interrupt
      missed=1;
      }
      }
      }

   INTCON=INTCON&0xFB;
   }
   if (PIR1 & 0x20)
    {           //Interrupt from bluetooth module about received data
        myRxBuffer = RCREG;
        myRxFlag = 1;
        PIR1 = PIR1 & 0xDF; // Clear the RCIF flag
    }
}

void main(){
//PORT Directions
TRISC=0x80;
TRISB=0x01;

Keypad_Init();
Lcd_Init();
clock[1]=0;
clock[0]=0;

//ADC
temp=0;
ADC_init();
//Buzzer is PORTA bit 3, Parallel LEDs are PORTA bit 4
PORTA= 0x00;

//Serial Communication Init
USART_Init();

 /*i = 0;
    while (welcome[i] != '.')
    {   USART_Tx(welcome[i]);
        i++;
    }
    USART_Tx('\r');
    USART_Tx('\n');

    i = 0;
    while (welcome2[i] != '.')
    {   USART_Tx(welcome2[i]);
        i++;
    }
    USART_Tx('\r');
    USART_Tx('\n');

    i = 0;
    while (stars[i] != '.')
    {   USART_Tx(stars[i]);
        i++;
    }
    USART_Tx('\r');
    USART_Tx('\n');*/

E=0;
//TMR0 Interrupt every 25 milisecond
OPTION_REG= 0x87;
TMR0=60;
INTCON=INTCON&0xEF;
INTCON= INTCON |0xA0;

configure();
msDelay(500);

while(1){
      temp=read_temp();
      display();
      msDelay(500);

     if(missed){
      USART_Tx('M');
      USART_Tx('D');
      USART_Tx('\r');
      USART_Tx('\n');
      missed=0;}

      /*if(myRxFlag){
        if (myRxBuffer=='r'){
         myRxFlag=0;
         Lcd_Cmd(_LCD_CLEAR);
         Lcd_Out(1,1,"# added pills:");
         Lcd_Chr(2,1,' ');
         pills+=in1();
         }
         if (myRxBuffer=='d'){
         drop_pill();
         myRxFlag=0;
         } }*/
}
}


void display(){
     Lcd_Cmd(_LCD_CLEAR);
    Lcd_Out(1,1,"Clock: ");
    Lcd_Chr_Cp(clock[0]/10+'0');
    Lcd_Chr_Cp(clock[0]%10+'0');
    Lcd_Chr_Cp(':');
    Lcd_Chr_Cp(clock[1]/10+'0');
    Lcd_Chr_Cp(clock[1]%10+'0');

    Lcd_Out(2,1,"Temperature: ");
    Lcd_Chr_Cp(temp/10+'0');
    Lcd_Chr_Cp(temp%10+'0');
    Lcd_Chr_Cp('C');
    msDelay(500);
    if (temp>templim){
      Lcd_Cmd(_LCD_CLEAR);
      Lcd_Out(1,1,"Temp Limit");
      Lcd_Out(2,1,"Exceeded");
      msDelay(2000);
      }

      /*if(pills<=lim){
      Lcd_Cmd(_LCD_CLEAR);
      Lcd_Out(1,1,"Remember to");
      Lcd_Out(2,1,"Refill");
      msDelay(2000);
      }*/

}

unsigned char in2(){
unsigned char c;
   unsigned char i=0, j=0;
for(i=0;i<2;i++){
    c=0;
    do{
    c=Keypad_Key_Press(); }
    while(c==0);
    if(i==0)
    j=keys[c]*10;
    else
    j+=keys[c];
    Lcd_Chr_Cp(keys[c]+'0');
    msDelay(500);
}

return j; }

unsigned char in1(){
unsigned char c;
       c=0;
               do{
    c=Keypad_Key_Press(); }
    while(c==0);
    Lcd_Chr_Cp(keys[c]+'0');
    msDelay(500);
    return keys[c];
}


void configure(){
   unsigned char i=0;
   unsigned char j=0;

    ask("Set Clock:");
    for (i=0;i<2;i++){
    if(i==0){
    clock[i]=in2()%24;
    Lcd_Chr_Cp(':'); }
    else
    clock[i]=in2()%60;
    msDelay(500);
    }

    ask("Set Daily Dose:");
    lim=in1()%5;

    for (j=0;j<lim;j++){
    Lcd_Cmd(_LCD_CLEAR);
    Lcd_Out(1,1,"Enter Alarm ");
    Lcd_Chr_Cp(j+1+'0');
    Lcd_Chr(2,1,' ');
    for (i=0;i<2;i++){
    if(i==0){
    a[j][i]=in2()%24;
    Lcd_Chr_Cp(':');}
    else
    a[j][i]=in2()%60;
    msDelay(500);
    }  }

    ask("Set Temp Lim:");
    templim=in2();
    msDelay(500);

    ask("Set # Pills:");
    pills=in1();
    msDelay(500);

    E=1;
    }

void ask( char *text){
Lcd_Cmd(_LCD_CLEAR);
    Lcd_Out(1,1,text);
    Lcd_Chr(2,1,' ');
}

    void ADC_init(void){
  ADCON1=0xCE;//Right Justify, Fosc/16, AN0 other PORTA and PORTE are digital
  ADCON0= 0x41;// ADC ON, Channel 0, Fosc/16
  TRISA=0x01;

}
unsigned int read_temp(void){
  unsigned int read;
  ADCON0 = ADCON0 | 0x04;// GO
  while( ADCON0 & 0x04);
  read=(ADRESH<<8)| ADRESL;
  return (read*500)/1023;
}



void servoRotate0() //0 Degree
{unsigned int i;
  for(i=0;i<50;i++)
  {
    PORTC = 0x01;
    Delay_us(800);
    PORTC = 0x00;
    Delay_us(19200);
  }
}

void servoRotate180() //180 Degree
{unsigned int i;
  for(i=0;i<50;i++)
  { PORTC= 0x01;
    Delay_us(2200);
    PORTC = 0x00;
    Delay_us(17800);
  }
}
void drop_pill(){
servoRotate180();
servoRotate0();
}

void USART_Init(void){
   SPBRG = 12; // 9600 bps
   TXSTA = 0x20;// 8-bit, Tx Enable, Asynchronus, Low Speed
   RCSTA = 0x90;// SP Enable, 8-bi, cont. Rx
   TRISC = 0x80;
   PIE1 = PIE1 | 0x20;// RCIE
   INTCON = 0xC0;}//GIE, PEIE
void USART_Tx(unsigned char myChar){
     while(!(TXSTA & 0x02));
     TXREG = myChar;}